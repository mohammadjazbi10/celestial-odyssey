import React, { useState } from 'react';
import { BookmarkCheck, Search, Download, FileSpreadsheet, FolderOpen } from 'lucide-react';

export default function MyInvestigationsPage({
  investigations = [],
  onReopenCase,
  onNavigate
}) {
  const [filterStatus, setFilterStatus] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filtered = investigations.filter((inv) => {
    const matchesFilter = filterStatus === 'all' || inv.status.toLowerCase().includes(filterStatus);
    const matchesSearch =
      inv.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      inv.ticId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      inv.hypothesis.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const handleExportAllJSON = () => {
    const blob = new Blob([JSON.stringify(investigations, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `polarix-saved-investigations-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleExportCSV = () => {
    const headers = ['ID', 'Target Title', 'TIC ID', 'Hypothesis', 'Status', 'Date', 'Transit Depth', 'Period', 'SNR'];
    const rows = investigations.map(i => [
      i.id,
      `"${i.title}"`,
      `"${i.ticId}"`,
      `"${i.hypothesis}"`,
      `"${i.status}"`,
      `"${i.date}"`,
      `"${i.depth || 'N/A'}"`,
      `"${i.period || 'N/A'}"`,
      `"${i.snr || 'N/A'}"`
    ]);

    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `polarix-investigations-${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-in fade-in duration-300">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8 pb-4 border-b border-[#ECE8DF]/15">
        <div>
          <div className="flex items-center gap-2 text-[#C5A059] text-xs font-sans font-bold tracking-[0.28em] uppercase mb-1">
            <BookmarkCheck className="w-4 h-4" />
            <span>PERSONAL WORKBENCH // LOCAL DOSSIERS</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-['Playfair_Display',serif] font-normal text-[#ECE8DF]">
            My Investigations
          </h1>
          <p className="text-xs sm:text-sm text-[#ECE8DF]/70 font-sans mt-1">
            A personal workbench, stored locally for the prototype, without a community feed.
          </p>
        </div>

        {/* Export Formats Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleExportAllJSON}
            className="chamfer-btn px-4 py-2 bg-[#1B1A18] hover:bg-[#23211E] border border-[#ECE8DF]/20 text-[#C5A059] text-xs font-['Cinzel',serif] tracking-wider flex items-center gap-1.5"
            title="Download full database as JSON"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export JSON</span>
          </button>

          <button
            onClick={handleExportCSV}
            className="chamfer-btn px-4 py-2 bg-[#1B1A18] hover:bg-[#23211E] border border-[#ECE8DF]/20 text-[#6EA893] text-xs font-['Cinzel',serif] tracking-wider flex items-center gap-1.5"
            title="Download table report as CSV"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>Download CSV</span>
          </button>
        </div>
      </div>

      {/* Main Container */}
      <div className="rounded-xl bg-[#1B1A18] border border-[#ECE8DF]/15 p-6 shadow-2xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-[#ECE8DF]/15">
          <div>
            <h2 className="text-2xl font-['Playfair_Display',serif] font-normal text-white">
              Saved investigations
            </h2>
            <p className="text-xs font-sans text-[#ECE8DF]/60 mt-0.5">
              Your hypotheses, completed missions, and generated case files ({investigations.length} recorded)
            </p>
          </div>

          {/* Filter & Search */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative">
              <Search className="w-4 h-4 text-[#ECE8DF]/40 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search dossiers..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-[#141312] border border-[#ECE8DF]/20 focus:border-[#C5A059] focus:outline-none rounded-lg py-1.5 pl-9 pr-3 text-xs text-white placeholder-stone-600 w-48 sm:w-56 font-sans"
              />
            </div>

            <div className="flex items-center gap-1 bg-[#141312] p-1 rounded-lg border border-[#ECE8DF]/15 text-xs font-sans">
              {['all', 'review', 'verification'].map((f) => (
                <button
                  key={f}
                  onClick={() => setFilterStatus(f)}
                  className={`px-3 py-1 rounded capitalize transition-all ${
                    filterStatus === f
                      ? 'bg-[#ECE8DF] text-[#141312] font-bold'
                      : 'text-[#ECE8DF]/60 hover:text-white'
                  }`}
                >
                  {f === 'all' ? 'All Cases' : f}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Saved Investigations List (from PDF Page 10) */}
        <div className="space-y-4 mt-6">
          {filtered.length > 0 ? (
            filtered.map((item) => (
              <div
                key={item.id}
                className="rounded-xl bg-[#141312] border border-[#ECE8DF]/15 hover:border-[#C5A059] p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition-all hover:bg-[#191816]"
              >
                <div>
                  <div className="flex items-center gap-3 mb-1">
                    <h3 className="text-lg font-serif font-bold text-white">
                      {item.title}
                    </h3>
                    <span className="text-[10px] font-mono text-[#C5A059] bg-[#1B1A18] px-2 py-0.5 rounded border border-[#C5A059]/30">
                      {item.ticId}
                    </span>
                  </div>

                  <div className="text-xs font-sans text-[#ECE8DF]/80 mt-1 flex flex-wrap items-center gap-3">
                    <span>
                      Hypothesis: <strong className="text-[#C5A059]">{item.hypothesis}</strong>
                    </span>
                    <span className="text-[#ECE8DF]/30">/</span>
                    <span className="capitalize font-semibold text-[#ECE8DF]">
                      {item.status}
                    </span>
                    <span className="text-[#ECE8DF]/30">/</span>
                    <span className="text-[#ECE8DF]/50">{item.date}</span>
                  </div>

                  {item.depth && (
                    <div className="text-[11px] font-mono text-[#ECE8DF]/60 mt-2 flex items-center gap-4">
                      <span>Depth: {item.depth}</span>
                      <span>Period: {item.period}</span>
                      <span>SNR: {item.snr} σ</span>
                    </div>
                  )}
                </div>

                {/* Reopen Button */}
                <button
                  onClick={() => {
                    if (onReopenCase) {
                      onReopenCase(item);
                    }
                    onNavigate('missions');
                  }}
                  className="chamfer-btn py-2 px-6 bg-[#ECE8DF] hover:bg-[#C5A059] text-[#141312] font-['Cinzel',serif] font-bold text-xs tracking-[0.16em] uppercase flex items-center justify-center gap-2 flex-shrink-0"
                >
                  <FolderOpen className="w-4 h-4" />
                  <span>Reopen</span>
                </button>
              </div>
            ))
          ) : (
            <div className="py-12 text-center text-[#ECE8DF]/50 font-sans text-xs">
              No investigations match the current filter or search criteria.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

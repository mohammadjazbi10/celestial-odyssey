// Realistic NASA TESS exoplanetary & stellar anomaly data

export const KPI_DATA = {
  starsAnalyzed: 300,
  flaggedCandidates: 24,
  investigations: 8,
  needsReview: 6,
};

export const EVENT_DISTRIBUTION = [
  { name: 'Repeating dips', count: 126, percent: 42, color: '#32D8F6', description: 'Periodic planetary transit or eclipsing binary candidates' },
  { name: 'Flares', count: 84, percent: 28, color: '#FFB020', description: 'Rapid magnetic reconnection explosive energy releases' },
  { name: 'Irregular', count: 54, percent: 18, color: '#9B83FF', description: 'Circumstellar dust clumps, pulsation, or accretion disks' },
  { name: 'Single dips', count: 36, percent: 12, color: '#52D9A0', description: 'Long-period mono-transits awaiting subsequent sector confirmation' }
];

// Generator for synthetic TESS light curve data
export function generateLightCurveData(type = 'repeating_dip', count = 120) {
  const points = [];
  const baseFlux = 1.0;
  const noiseLevel = 0.003;

  for (let i = 0; i < count; i++) {
    const t = 1800 + (i * 0.22); // BTJD
    let flux = baseFlux + (Math.random() - 0.5) * noiseLevel;
    let isDip = false;
    let isFlare = false;

    if (type === 'repeating_dip') {
      // Repeat every 24 points (~5.28 days)
      const phase = (i % 24);
      if (phase >= 11 && phase <= 13) {
        const depth = phase === 12 ? 0.024 : 0.016;
        flux -= depth;
        isDip = true;
      }
    } else if (type === 'flare') {
      // Sudden sharp flare at point 48 with exponential decay
      if (i >= 48 && i <= 60) {
        const decay = Math.exp(-(i - 48) / 2.5);
        flux += 0.045 * decay;
        isFlare = true;
      }
    } else if (type === 'irregular') {
      // Multi-frequency wave with varying depth
      flux += Math.sin(i * 0.2) * 0.008 + Math.cos(i * 0.07) * 0.005;
      if (i % 30 >= 14 && i % 30 <= 16) {
        flux -= 0.012;
        isDip = true;
      }
    } else if (type === 'single_dip') {
      // Single deep transit at point 55
      if (i >= 53 && i <= 57) {
        const centerDist = Math.abs(i - 55);
        flux -= (0.028 - centerDist * 0.008);
        isDip = true;
      }
    }

    points.push({
      time: parseFloat(t.toFixed(2)),
      flux: parseFloat(flux.toFixed(5)),
      isDip,
      isFlare,
      qualityFlag: Math.random() < 0.04 ? 'MOMENTUM_DUMP' : null
    });
  }

  return points;
}

export const SKY_TARGETS = [
  {
    id: 'TIC-123456',
    name: 'TIC 123456',
    sector: 'Sector 05',
    ra: 135.42,
    dec: -28.71,
    xPercent: 68,
    yPercent: 32,
    event: 'Repeating dip',
    category: 'dips',
    rank: '08 / 300',
    status: 'Pending',
    magnitude: 10.4,
    period: '4.887 days',
    depth: '1.42%',
    snr: 28.4
  },
  {
    id: 'TIC-994201',
    name: 'TIC 994201',
    sector: 'Sector 08',
    ra: 84.15,
    dec: 12.38,
    xPercent: 38,
    yPercent: 44,
    event: 'Stellar flare',
    category: 'flares',
    rank: '02 / 300',
    status: 'Flagged',
    magnitude: 11.2,
    period: 'N/A (Stochastic)',
    depth: '+4.5% peak',
    snr: 42.1
  },
  {
    id: 'TIC-773120',
    name: 'TIC 773120',
    sector: 'Sector 14',
    ra: 210.88,
    dec: -45.19,
    xPercent: 52,
    yPercent: 70,
    event: 'Irregular rhythm',
    category: 'strange',
    rank: '14 / 300',
    status: 'Under Review',
    magnitude: 9.8,
    period: 'Quasi-periodic',
    depth: '1.18%',
    snr: 19.3
  },
  {
    id: 'TIC-441092',
    name: 'TIC 441092',
    sector: 'Sector 02',
    ra: 34.62,
    dec: -62.05,
    xPercent: 24,
    yPercent: 58,
    event: 'Single deep dip',
    category: 'dips',
    rank: '05 / 300',
    status: 'Pending',
    magnitude: 12.1,
    period: '> 27 days',
    depth: '2.80%',
    snr: 33.7
  },
  {
    id: 'TIC-310842',
    name: 'TIC 310842',
    sector: 'Sector 19',
    ra: 165.20,
    dec: +18.45,
    xPercent: 78,
    yPercent: 62,
    event: 'Repeating dip',
    category: 'dips',
    rank: '12 / 300',
    status: 'Verified Candidate',
    magnitude: 10.1,
    period: '3.14 days',
    depth: '0.85%',
    snr: 22.9
  },
  {
    id: 'TIC-852190',
    name: 'TIC 852190',
    sector: 'Sector 22',
    ra: 295.11,
    dec: -10.22,
    xPercent: 84,
    yPercent: 25,
    event: 'Multi-flare complex',
    category: 'flares',
    rank: '18 / 300',
    status: 'Flagged',
    magnitude: 13.5,
    period: 'Transient',
    depth: '+6.1% peak',
    snr: 39.8
  }
];

export const CANDIDATES = [
  {
    id: 'cand-1',
    ticId: 'TIC 123456',
    title: 'The Repeating Shadow',
    sector: 'Sector 05',
    category: 'hidden_shadows',
    eventType: 'Periodic dips',
    status: 'verification pending',
    rank: 'Rank #08',
    period: '4.887 days',
    depth: '1.42%',
    curveType: 'repeating_dip',
    description: 'Distinctive recurring box-shaped flux drops with consistent duration across 6 consecutive transits.'
  },
  {
    id: 'cand-2',
    ticId: 'TIC 994201',
    title: 'The Sudden Flash',
    sector: 'Sector 08',
    category: 'sudden_flashes',
    eventType: 'Stellar flares',
    status: 'flagged anomaly',
    rank: 'Rank #02',
    period: 'N/A (Impulsive)',
    depth: '+4.5% flux burst',
    curveType: 'flare',
    description: 'Prominent coronal reconnection flare with rapid 15-minute rise time followed by exponential thermal decay.'
  },
  {
    id: 'cand-3',
    ticId: 'TIC 773120',
    title: 'The Strange Rhythm',
    sector: 'Sector 14',
    category: 'strange_patterns',
    eventType: 'Irregular changes',
    status: 'investigation pending',
    rank: 'Rank #14',
    period: 'Quasi-periodic',
    depth: '1.18% variable',
    curveType: 'irregular',
    description: 'Complex asynchronous flux variations with possible circumstellar debris disk or eclipsing contact binary behavior.'
  },
  {
    id: 'cand-4',
    ticId: 'TIC 441092',
    title: 'The Vanishing Light',
    sector: 'Sector 02',
    category: 'single_mysteries',
    eventType: 'One-time dips',
    status: 'verification pending',
    rank: 'Rank #05',
    period: '> 27.4 days',
    depth: '2.80% deep eclipse',
    curveType: 'single_dip',
    description: 'High-signal solitary ingress and egress event indicating a cold Jovian world with orbit exceeding TESS sector baseline.'
  }
];

export const MISSIONS = [
  {
    id: 'mission-repeating-shadow',
    title: 'The Repeating Shadow',
    difficulty: 'BEGINNER',
    difficultyColor: '#52D9A0',
    ticId: 'TIC 123456',
    sector: 'Sector 05',
    curveType: 'repeating_dip',
    whatYouNotice: 'The brightness appears to dip at roughly regular intervals every ~4.9 days.',
    hypothesisOptions: [
      { id: 'planet', label: 'Planet transit', note: 'Consistent depth and flat bottom' },
      { id: 'binary', label: 'Eclipsing binary', note: 'Alternating odd/even depth or V-shape' },
      { id: 'artifact', label: 'Instrument artifact', note: 'Correlated with spacecraft momentum dumps' },
      { id: 'unsure', label: 'Unsure', note: 'Requires deeper Signal Lab investigation' }
    ]
  },
  {
    id: 'mission-sudden-flash',
    title: 'The Sudden Flash',
    difficulty: 'BEGINNER',
    difficultyColor: '#52D9A0',
    ticId: 'TIC 994201',
    sector: 'Sector 08',
    curveType: 'flare',
    whatYouNotice: 'A massive spike in stellar luminosity occurring in a matter of minutes.',
    hypothesisOptions: [
      { id: 'flare', label: 'Stellar flare / Coronal mass ejection', note: 'Magnetic reconnection on active M-dwarf' },
      { id: 'asteroid', label: 'Microlensing event', note: 'Gravitational magnification' },
      { id: 'artifact', label: 'Cosmic ray hit on CCD detector', note: 'Single-pixel contamination' },
      { id: 'unsure', label: 'Unsure', note: 'Requires multi-cadence examination' }
    ]
  },
  {
    id: 'mission-strange-rhythm',
    title: 'The Strange Rhythm',
    difficulty: 'INTERMEDIATE',
    difficultyColor: '#FFB020',
    ticId: 'TIC 773120',
    sector: 'Sector 14',
    curveType: 'irregular',
    whatYouNotice: 'Multiple superimposed oscillation frequencies with varying dip depths.',
    hypothesisOptions: [
      { id: 'binary_triplet', label: 'Hierarchical triple star system', note: 'Compound occultation' },
      { id: 'dust_disk', label: 'Circumstellar dust clump / disintegrating planetesimal', note: 'Asymmetric transit shapes' },
      { id: 'pulsation', label: 'Gamma Doradus stellar pulsation', note: 'Gravity-mode pulsations' },
      { id: 'unsure', label: 'Unsure', note: 'Run Fourier transform and BLS' }
    ]
  },
  {
    id: 'mission-vanishing-light',
    title: 'The Vanishing Light',
    difficulty: 'ADVANCED',
    difficultyColor: '#9B83FF',
    ticId: 'TIC 441092',
    sector: 'Sector 02',
    curveType: 'single_dip',
    whatYouNotice: 'A single deep transit event spanning 8 hours with no counterpart in this sector.',
    hypothesisOptions: [
      { id: 'long_period', label: 'Long-period gas giant planet', note: 'Year-long orbit beyond 1 AU' },
      { id: 'ringed_world', label: 'Exoplanet with extensive ring system', note: 'Extended ingress duration' },
      { id: 'background_eb', label: 'Background blended eclipsing binary', note: 'Diluted occultation' },
      { id: 'unsure', label: 'Unsure', note: 'Cross-match with subsequent TESS cycles' }
    ]
  }
];

export const INITIAL_INVESTIGATIONS = [
  {
    id: 'inv-1',
    title: 'The Repeating Shadow',
    ticId: 'TIC 123456 / S05',
    hypothesis: 'Planet transit',
    status: 'under review',
    statusColor: '#32D8F6',
    date: 'Nov 10, 2026',
    depth: '1.42%',
    period: '4.887 days',
    snr: 28.4
  },
  {
    id: 'inv-2',
    title: 'The Sudden Flash',
    ticId: 'TIC 994201 / S08',
    hypothesis: 'Stellar flare',
    status: 'needs verification',
    statusColor: '#FFB020',
    date: 'Nov 08, 2026',
    depth: '+4.5% burst',
    period: 'Transient',
    snr: 42.1
  },
  {
    id: 'inv-3',
    title: 'The Strange Rhythm',
    ticId: 'TIC 773120 / S14',
    hypothesis: 'Circumstellar dust disk',
    status: 'investigation pending',
    statusColor: '#9B83FF',
    date: 'Nov 05, 2026',
    depth: '1.18% variable',
    period: 'Quasi-periodic',
    snr: 19.3
  }
];

export const SCIENCE_LEVELS = {
  beginner: {
    title: 'Beginner Mode',
    summary: 'A light curve is a celestial brightness movie chart. When an orbiting exoplanet crosses in front of its star, it temporarily blocks a fraction of the starlight, creating a small dip in brightness.',
    transitExplanation: 'Imagine holding a marble in front of a bright lightbulb. From across the room, the bulb looks slightly dimmer while the marble blocks the beam. In exoplanet science, that small dip reveals the planet size and how fast it circles its sun.',
    tags: ['Star Brightness', 'Shadow Dips', 'Planetary Shadows', 'Telescope Eyes']
  },
  student: {
    title: 'Student Mode',
    summary: 'A periodic dip may be caused by a planetary transit or an eclipsing binary star. Compare period, transit duration, transit depth, and quality flags to vet candidate signals.',
    transitExplanation: 'The fractional decrease in flux (ΔF/F) approximates (Rp / R*)^2, where Rp is the radius of the planet and R* is the stellar radius. Box Least Squares (BLS) periodograms identify periodicities in time-series photometry by folding light curves across trial trial orbital periods.',
    tags: ['Transit Depth (Rp/R*)²', 'Orbital Period (P)', 'Transit Duration', 'BLS Periodogram', 'Eclipsing Binaries']
  },
  researcher: {
    title: 'Researcher Mode',
    summary: 'Rigorous vetting requires comparing Raw Simple Aperture Photometry (SAP) with Pre-search Data Conditioning (PDCSAP), detrending instrumental systematics via cotrending basis vectors (CBVs), and verifying centroid motion.',
    transitExplanation: 'Candidate validation requires limb-darkening modeled transit fitting (Mandel & Agol formalism), odd-even transit depth consistency checks (Δδ < 3σ) to rule out secondary eclipses of blended binaries, and pixel-level difference imaging to ensure target centroid stability during in-transit cadences.',
    tags: ['PDCSAP Flux', 'Cotrending Basis Vectors (CBVs)', 'Mandel-Agol Limb Darkening', 'Centroid Offset Analysis', 'Odd-Even Vetting']
  }
};

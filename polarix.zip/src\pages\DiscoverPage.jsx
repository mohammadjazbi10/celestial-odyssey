import React, { useState, useMemo } from 'react';
import { Radio, Search, SlidersHorizontal, ArrowRight, CheckCircle2 } from 'lucide-react';
import LightCurveChart from '../components/LightCurveChart';
import { CANDIDATES, generateLightCurveData } from '../data/mockData';

export default function DiscoverPage({ onNavigate, onSelectCandidate }) {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('rank');

  const candidateCurves = useMemo(() => {
    return {
      'cand-1': generateLightCurveData('repeating_dip', 80),
      'cand-2': generateLightCurveData('flare', 80),
      'cand-3': generateLightCurveData('irregular', 80),
      'cand-4': generateLightCurveData('single_dip', 80),
    };
  }, []);

  // 4 Categories matching Innovision 4 missions palette
  const categories = [
    {
      id: 'hidden_shadows',
      title: 'HIDDEN SHADOWS',
      sub: 'Periodic dips',
      desc: 'Transiting exoplanet worlds blocking stellar disks at regular orbital intervals.',
      color: '#D97757'
    },
    {
      id: 'sudden_flashes',
      title: 'SUDDEN FLASHES',
      sub: 'Stellar flares',
      desc: 'Explosive magnetic reconnection events from high-energy stellar coronae.',
      color: '#C5A059'
    },
    {
      id: 'strange_patterns',
      title: 'STRANGE PATTERNS',
      sub: 'Irregular changes',
      desc: 'Asymmetrical dips, circumstellar dust clouds, or multi-star eclipses.',
      color: '#9D78A8'
    },
    {
      id: 'single_mysteries',
      title: 'SINGLE MYSTERIES',
      sub: 'One-time dips',
      desc: 'Solitary deep occultations from long-period planets or wandering bodies.',
      color: '#6EA893'
    }
  ];

  const filteredCandidates = useMemo(() => {
    return CANDIDATES.filter(cand => {
      const matchesCategory = selectedCategory === 'all' || cand.category === selectedCategory;
      const matchesSearch =
        cand.ticId.toLowerCase().includes(searchQuery.toLowerCase()) ||
        cand.title.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    }).sort((a, b) => {
      if (sortBy === 'rank') return a.rank.localeCompare(b.rank);
      if (sortBy === 'event') return a.eventType.localeCompare(b.eventType);
      return a.status.localeCompare(b.status);
    });
  }, [selectedCategory, searchQuery, sortBy]);

  const handleExploreCandidate = (candId) => {
    if (onSelectCandidate) {
      onSelectCandidate(candId);
    }
    onNavigate('missions');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-in fade-in duration-300">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8 pb-4 border-b border-[#ECE8DF]/15">
        <div>
          <div className="flex items-center gap-2 text-[#C5A059] text-xs font-sans font-bold tracking-[0.28em] uppercase mb-1">
            <Radio className="w-4 h-4" />
            <span>EXOPLANETARY TAXONOMY // ANOMALY CLUSTERS</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-['Playfair_Display',serif] font-normal text-[#ECE8DF]">
            Discover anomalies
          </h1>
          <p className="text-xs sm:text-sm text-[#ECE8DF]/70 font-sans mt-1">
            Browse four understandable event families instead of requiring TIC IDs or astronomy knowledge.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="px-3.5 py-1.5 rounded-lg bg-[#1B1A18] border border-[#ECE8DF]/20 text-[11px] font-sans tracking-wider text-[#C5A059]">
            TESS / DEMO DATA
          </div>
        </div>
      </div>

      {/* 4 Category Tiles (from PDF page 4) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
        {categories.map((cat) => {
          const isSelected = selectedCategory === cat.id;
          return (
            <div
              key={cat.id}
              onClick={() => setSelectedCategory(isSelected ? 'all' : cat.id)}
              className={`cursor-pointer rounded-xl bg-[#1B1A18] border p-5 flex flex-col justify-between transition-all duration-300 hover:-translate-y-1 ${
                isSelected
                  ? 'border-[#C5A059] shadow-xl bg-[#23211E]'
                  : 'border-[#ECE8DF]/15 hover:border-[#ECE8DF]/40'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span
                    className="text-xs font-['Cinzel',serif] font-bold tracking-wider"
                    style={{ color: cat.color }}
                  >
                    {cat.title}
                  </span>
                  {isSelected && <CheckCircle2 className="w-4 h-4 text-[#C5A059]" />}
                </div>
                <div className="text-base font-serif font-bold text-white mb-2">
                  {cat.sub}
                </div>
                <p className="text-xs text-[#ECE8DF]/70 leading-relaxed font-sans">
                  {cat.desc}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-[#ECE8DF]/15 flex items-center justify-between text-xs font-sans">
                <span className={isSelected ? 'text-[#C5A059] font-bold' : 'text-[#ECE8DF]/60'}>
                  {isSelected ? 'Active filter' : 'Explore category'}
                </span>
                <ArrowRight className={`w-3.5 h-3.5 ${isSelected ? 'text-[#C5A059] translate-x-1' : 'text-[#ECE8DF]/40'}`} />
              </div>
            </div>
          );
        })}
      </div>

      {/* Candidate Gallery Header & Controls */}
      <div className="rounded-xl bg-[#1B1A18] border border-[#ECE8DF]/15 p-6 shadow-xl mb-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-[#ECE8DF]/15">
          <div>
            <h2 className="text-2xl font-['Playfair_Display',serif] font-normal text-white">
              Candidate gallery
            </h2>
            <div className="text-xs font-sans text-[#ECE8DF]/60 mt-0.5">
              Showing {filteredCandidates.length} celestial candidates
            </div>
          </div>

          {/* Search & Sort Controls */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative">
              <Search className="w-4 h-4 text-[#ECE8DF]/40 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search: TIC ID or name"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-[#141312] border border-[#ECE8DF]/20 focus:border-[#C5A059] focus:outline-none rounded-lg py-1.5 pl-9 pr-3 text-xs text-white placeholder-stone-600 w-48 sm:w-56"
              />
            </div>

            <div className="flex items-center gap-1.5 bg-[#141312] border border-[#ECE8DF]/20 rounded-lg px-2.5 py-1 text-xs font-mono text-[#ECE8DF]/80">
              <SlidersHorizontal className="w-3.5 h-3.5 text-[#C5A059]" />
              <span className="text-[#ECE8DF]/50">Sort:</span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="bg-transparent focus:outline-none text-[#ECE8DF] text-xs cursor-pointer font-mono"
              >
                <option value="rank" className="bg-[#1B1A18]">Anomaly rank</option>
                <option value="event" className="bg-[#1B1A18]">Event family</option>
                <option value="verification" className="bg-[#1B1A18]">Verification status</option>
              </select>
            </div>

            {selectedCategory !== 'all' && (
              <button
                onClick={() => setSelectedCategory('all')}
                className="text-xs font-sans text-[#C5A059] hover:text-[#ECE8DF] underline underline-offset-2"
              >
                Clear filter
              </button>
            )}
          </div>
        </div>

        {/* Candidate Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
          {filteredCandidates.map((candidate) => (
            <div
              key={candidate.id}
              className="rounded-xl bg-[#141312] border border-[#ECE8DF]/15 hover:border-[#C5A059] p-4 transition-all duration-200 hover:shadow-xl flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-base font-serif font-bold text-white">
                    {candidate.title}
                  </h3>
                  <span className="text-[10px] font-mono text-[#C5A059] bg-[#1B1A18] px-2 py-0.5 rounded border border-[#C5A059]/30">
                    {candidate.rank}
                  </span>
                </div>

                {/* Interactive Mini Light Curve */}
                <div className="my-3">
                  <LightCurveChart
                    data={candidateCurves[candidate.id]}
                    height={150}
                    showMarkers={false}
                    interactive={false}
                  />
                </div>

                <div className="text-[11px] font-mono text-[#ECE8DF]/60 mb-1">
                  {candidate.ticId} / {candidate.status}
                </div>
                <p className="text-xs text-[#ECE8DF]/80 font-sans line-clamp-2">
                  {candidate.description}
                </p>
              </div>

              {/* Action Button */}
              <button
                onClick={() => handleExploreCandidate(candidate.id)}
                className="chamfer-btn mt-4 w-full py-2.5 px-3 bg-[#ECE8DF] hover:bg-[#C5A059] text-[#141312] font-['Cinzel',serif] font-bold text-xs tracking-[0.16em] uppercase flex items-center justify-center gap-1.5"
              >
                <span>Explore candidate</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

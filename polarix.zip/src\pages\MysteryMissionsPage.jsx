import React, { useState, useMemo } from 'react';
import { Target, ArrowRight, CheckCircle2, Download, Printer, Copy, Check, Play, RefreshCw } from 'lucide-react';
import LightCurveChart from '../components/LightCurveChart';
import { MISSIONS, generateLightCurveData } from '../data/mockData';

export default function MysteryMissionsPage({
  selectedCandidateId = 'cand-1',
  onSaveInvestigation,
  onNavigate
}) {
  const [activeTab, setActiveTab] = useState('mission');
  const [selectedMissionId, setSelectedMissionId] = useState('mission-repeating-shadow');
  
  // Workspace State
  const [hypothesis, setHypothesis] = useState('planet');
  const [submissionFeedback, setSubmissionFeedback] = useState(null);

  // Signal Lab State
  const [curveViewMode, setCurveViewMode] = useState('pdcsap');
  const [detrendMode, setDetrendMode] = useState('standard');
  const [showEventMarkers, setShowEventMarkers] = useState(true);
  const [showQualityFlags, setShowQualityFlags] = useState(true);

  // Gemma AI Investigator State
  const [isInvestigating, setIsInvestigating] = useState(false);
  const [aiStep, setAiStep] = useState(4);
  const [copiedSummary, setCopiedSummary] = useState(false);

  const currentMission = useMemo(() => {
    return MISSIONS.find(m => m.id === selectedMissionId) || MISSIONS[0];
  }, [selectedMissionId]);

  const activeCurveData = useMemo(() => {
    return generateLightCurveData(currentMission.curveType, 120);
  }, [currentMission]);

  const handleSubmitHypothesis = () => {
    const chosen = currentMission.hypothesisOptions.find(o => o.id === hypothesis);
    const newInvestigation = {
      id: `inv-${Date.now()}`,
      title: currentMission.title,
      ticId: `${currentMission.ticId} / ${currentMission.sector}`,
      hypothesis: chosen ? chosen.label : hypothesis,
      status: 'under review',
      statusColor: '#C5A059',
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      depth: '1.42%',
      period: '4.887 days',
      snr: 28.4
    };

    if (onSaveInvestigation) {
      onSaveInvestigation(newInvestigation);
    }

    setSubmissionFeedback(`Hypothesis "${chosen?.label || hypothesis}" recorded in case file.`);
    setTimeout(() => setSubmissionFeedback(null), 4000);
  };

  const handleRunAiInvestigation = () => {
    setIsInvestigating(true);
    setAiStep(1);

    setTimeout(() => setAiStep(2), 700);
    setTimeout(() => setAiStep(3), 1500);
    setTimeout(() => {
      setAiStep(4);
      setIsInvestigating(false);
    }, 2200);
  };

  const handleExportJSON = () => {
    const caseData = {
      caseId: `${currentMission.ticId}-${currentMission.sector}`,
      target: currentMission.title,
      ticId: currentMission.ticId,
      sector: currentMission.sector,
      status: 'candidate, not confirmed discovery',
      hypothesis: hypothesis,
      measurements: {
        period: '~4.887 days',
        depth: '1.42%',
        snr: 28.4,
        detrending: detrendMode,
        viewMode: curveViewMode
      },
      provenance: 'NASA TESS / MAST / Polarix Science Lab',
      timestamp: new Date().toISOString()
    };

    const blob = new Blob([JSON.stringify(caseData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `CaseFile-${currentMission.ticId}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleCopySummary = () => {
    const summaryText = `POLARIX SCIENTIFIC CASE FILE\nTarget: ${currentMission.title} (${currentMission.ticId} / ${currentMission.sector})\nStatus: Candidate exoplanet transit\nHypothesis: ${hypothesis}\nPeriod: ~4.9 days | Depth: 1.42% | SNR: 28.4\nProvenance: NASA TESS / MAST Science Archive`;
    navigator.clipboard.writeText(summaryText);
    setCopiedSummary(true);
    setTimeout(() => setCopiedSummary(false), 3000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-in fade-in duration-300">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8 pb-4 border-b border-[#ECE8DF]/15">
        <div>
          <div className="flex items-center gap-2 text-[#C5A059] text-xs font-sans font-bold tracking-[0.28em] uppercase mb-1">
            <Target className="w-4 h-4" />
            <span>EXOPLANETARY VETTING LAB // TESS EVIDENCE PIPELINE</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-['Playfair_Display',serif] font-normal text-[#ECE8DF]">
            Mystery Missions & Workspace
          </h1>
          <p className="text-xs sm:text-sm text-[#ECE8DF]/70 font-sans mt-1">
            Guided learning uses actual candidate IDs; explore evidence before inspecting AI investigator traces.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="px-3.5 py-1.5 rounded-lg bg-[#1B1A18] border border-[#ECE8DF]/20 text-[11px] font-sans tracking-wider text-[#C5A059]">
            TESS / DEMO DATA
          </div>
        </div>
      </div>

      {/* SECTION 1: MYSTERY MISSIONS GALLERY (PDF Page 5 - 4 Large Boxes) */}
      <div className="mb-12">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-2xl font-['Playfair_Display',serif] font-normal text-white">
              Mystery Missions gallery
            </h2>
            <p className="text-xs font-sans text-[#ECE8DF]/60 mt-0.5">
              Select a mission below to load its linked candidate, light curve plot, and scientific workspace.
            </p>
          </div>
        </div>

        {/* 4 Large Mission Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {MISSIONS.map((mission) => {
            const isSelected = selectedMissionId === mission.id;
            return (
              <div
                key={mission.id}
                onClick={() => setSelectedMissionId(mission.id)}
                className={`cursor-pointer rounded-xl bg-[#1B1A18] border p-5 flex flex-col justify-between transition-all duration-300 ${
                  isSelected
                    ? 'border-[#C5A059] shadow-xl bg-[#23211E]'
                    : 'border-[#ECE8DF]/15 hover:border-[#ECE8DF]/40'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-lg font-serif font-bold text-white">
                      {mission.title}
                    </h3>
                    <span
                      className="text-[10px] font-sans font-bold px-2 py-0.5 rounded border uppercase tracking-wider"
                      style={{
                        color: mission.difficultyColor,
                        borderColor: `${mission.difficultyColor}55`,
                        backgroundColor: `${mission.difficultyColor}15`
                      }}
                    >
                      {mission.difficulty}
                    </span>
                  </div>

                  <div className="text-xs font-mono text-[#ECE8DF]/60 mb-3">
                    {mission.ticId} / {mission.sector}
                  </div>

                  {/* Light Curve Preview */}
                  <div className="my-2">
                    <LightCurveChart
                      data={generateLightCurveData(mission.curveType, 90)}
                      height={140}
                      showMarkers={false}
                      interactive={false}
                    />
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-[#ECE8DF]/15 flex items-center justify-between">
                  <span className="text-xs text-[#ECE8DF]/60 font-mono">
                    TIME (BTJD)
                  </span>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedMissionId(mission.id);
                      const el = document.getElementById('candidate-workspace-section');
                      el?.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className={`chamfer-btn py-2 px-5 text-xs font-['Cinzel',serif] tracking-wider uppercase transition-all flex items-center gap-1.5 ${
                      isSelected
                        ? 'bg-[#ECE8DF] text-[#141312] font-bold shadow-md'
                        : 'bg-[#141312] text-[#ECE8DF] hover:bg-[#ECE8DF] hover:text-[#141312]'
                    }`}
                  >
                    <span>{isSelected ? 'Active Mission' : 'Start mission'}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* SECTION 2: CANDIDATE / MISSION WORKSPACE (PDF Pages 6, 7, 8, 9) */}
      <div
        id="candidate-workspace-section"
        className="rounded-xl bg-[#1B1A18] border border-[#ECE8DF]/15 p-6 shadow-2xl scroll-mt-20"
      >
        {/* Workspace Top Bar */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-[#ECE8DF]/15">
          <div>
            <div className="text-[10px] font-sans font-bold tracking-[0.28em] text-[#C5A059] uppercase mb-1">
              CANDIDATE / MISSION WORKSPACE
            </div>
            <h2 className="text-3xl font-['Playfair_Display',serif] font-normal text-white uppercase">
              {currentMission.title}
            </h2>
            <div className="text-xs font-mono text-[#ECE8DF]/60 mt-1">
              {currentMission.ticId} / {currentMission.sector} / PERIODIC DIMMING / UNVERIFIED
            </div>
          </div>

          {/* Subnavigation Tabs */}
          <div className="flex flex-wrap items-center gap-1.5 bg-[#141312] p-1.5 rounded-lg border border-[#ECE8DF]/15">
            {[
              { id: 'mission', label: 'Mission' },
              { id: 'lab', label: 'Signal Lab' },
              { id: 'gemma', label: 'AI Investigator' },
              { id: 'casefile', label: 'Case File' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-1.5 px-4 rounded text-xs font-['Cinzel',serif] tracking-wider transition-all ${
                  activeTab === tab.id
                    ? 'bg-[#ECE8DF] text-[#141312] font-bold shadow-sm'
                    : 'text-[#ECE8DF]/60 hover:text-white'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* TAB 1: MISSION WORKSPACE (PDF Page 6) */}
        {activeTab === 'mission' && (
          <div className="mt-6 space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Left 2 Cols: What do you notice & Light Curve */}
              <div className="lg:col-span-2 space-y-4">
                <div className="bg-[#141312] p-4 rounded-lg border border-[#ECE8DF]/15">
                  <h3 className="text-sm font-serif font-bold text-white mb-1">
                    What do you notice?
                  </h3>
                  <p className="text-xs text-[#C5A059] font-sans">
                    {currentMission.whatYouNotice}
                  </p>
                </div>

                <LightCurveChart
                  data={activeCurveData}
                  height={280}
                  showMarkers={true}
                  title={`${currentMission.ticId} // LIGHT CURVE OBSERVATION (BTJD)`}
                />
              </div>

              {/* Right Col: Your Hypothesis Form */}
              <div className="rounded-lg bg-[#141312] border border-[#ECE8DF]/15 p-5 flex flex-col justify-between">
                <div>
                  <h3 className="text-lg font-['Playfair_Display',serif] font-normal text-white">
                    Your hypothesis
                  </h3>
                  <p className="text-xs text-[#ECE8DF]/60 font-sans mt-1 mb-4">
                    What could cause the repeated dips in this light curve?
                  </p>

                  <div className="space-y-3">
                    {currentMission.hypothesisOptions.map((opt) => (
                      <label
                        key={opt.id}
                        className={`flex items-start gap-3 p-3 rounded-lg border cursor-pointer transition-all ${
                          hypothesis === opt.id
                            ? 'bg-[#1B1A18] border-[#C5A059] text-white'
                            : 'border-[#ECE8DF]/15 text-[#ECE8DF]/80 hover:border-[#ECE8DF]/40'
                        }`}
                      >
                        <input
                          type="radio"
                          name="hypothesis"
                          value={opt.id}
                          checked={hypothesis === opt.id}
                          onChange={() => setHypothesis(opt.id)}
                          className="mt-1 accent-[#C5A059]"
                        />
                        <div className="flex flex-col">
                          <span className="text-xs font-semibold">{opt.label}</span>
                          <span className="text-[10px] text-[#ECE8DF]/50 font-sans mt-0.5">{opt.note}</span>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>

                <div className="mt-6 pt-4 border-t border-[#ECE8DF]/15">
                  {submissionFeedback && (
                    <div className="mb-3 p-2.5 rounded bg-[#1B1A18] border border-[#C5A059]/40 text-[#C5A059] text-xs font-sans flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-[#C5A059] flex-shrink-0" />
                      <span>{submissionFeedback}</span>
                    </div>
                  )}

                  <button
                    onClick={handleSubmitHypothesis}
                    className="chamfer-btn w-full py-3 px-4 bg-[#ECE8DF] hover:bg-[#C5A059] text-[#141312] font-['Cinzel',serif] font-bold text-xs tracking-[0.16em] uppercase flex items-center justify-center gap-2"
                  >
                    <span>Submit interpretation</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: SIGNAL LAB / INTERACTIVE VERIFICATION (PDF Page 7) */}
        {activeTab === 'lab' && (
          <div className="mt-6 space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Left 2 Cols: Brightness Experiment Plot & Data Toggles */}
              <div className="lg:col-span-2 space-y-4">
                <div>
                  <h3 className="text-xl font-['Playfair_Display',serif] font-normal text-white">
                    Brightness experiment
                  </h3>
                  <p className="text-xs text-[#ECE8DF]/70 font-sans">
                    Plotly interactive inspection: zoom, hover cursor, event markers, and raw aperture comparison
                  </p>
                </div>

                <LightCurveChart
                  data={activeCurveData}
                  height={280}
                  detrendMode={detrendMode}
                  viewMode={curveViewMode}
                  showMarkers={showEventMarkers}
                  showQualityFlags={showQualityFlags}
                  title="TIME (BTJD) // APERTURE PHOTOMETRY COMPARISON"
                />

                {/* Data Processing Buttons */}
                <div className="flex flex-wrap items-center gap-2 pt-2">
                  <button
                    onClick={() => setCurveViewMode('sap')}
                    className={`chamfer-btn px-4 py-2 text-xs font-sans tracking-wide transition-all ${
                      curveViewMode === 'sap'
                        ? 'bg-[#ECE8DF] text-[#141312] font-bold'
                        : 'bg-[#141312] text-[#ECE8DF]/80 border border-[#ECE8DF]/20 hover:border-[#C5A059]'
                    }`}
                  >
                    Raw SAP
                  </button>

                  <button
                    onClick={() => setCurveViewMode('pdcsap')}
                    className={`chamfer-btn px-4 py-2 text-xs font-sans tracking-wide transition-all ${
                      curveViewMode === 'pdcsap'
                        ? 'bg-[#ECE8DF] text-[#141312] font-bold'
                        : 'bg-[#141312] text-[#ECE8DF]/80 border border-[#ECE8DF]/20 hover:border-[#C5A059]'
                    }`}
                  >
                    Corrected PDCSAP
                  </button>

                  <button
                    onClick={() => setShowQualityFlags(!showQualityFlags)}
                    className={`chamfer-btn px-4 py-2 text-xs font-sans tracking-wide transition-all ${
                      showQualityFlags
                        ? 'bg-[#D97757]/20 border border-[#D97757] text-[#D97757]'
                        : 'bg-[#141312] text-[#ECE8DF]/60 border border-[#ECE8DF]/20'
                    }`}
                  >
                    Quality flagged: {showQualityFlags ? 'VISIBLE' : 'HIDDEN'}
                  </button>

                  <button
                    onClick={() => {
                      setCurveViewMode('pdcsap');
                      setDetrendMode('standard');
                      setShowEventMarkers(true);
                      setShowQualityFlags(true);
                    }}
                    className="chamfer-btn px-4 py-2 text-xs font-sans tracking-wide bg-[#141312] hover:bg-[#23211E] text-[#ECE8DF]/60 hover:text-white border border-[#ECE8DF]/20"
                  >
                    Reset
                  </button>
                </div>
              </div>

              {/* Right Col: Analysis Controls & Measurements */}
              <div className="rounded-lg bg-[#141312] border border-[#ECE8DF]/15 p-5 flex flex-col justify-between">
                <div>
                  <h3 className="text-xl font-['Playfair_Display',serif] font-normal text-white">
                    Analysis controls
                  </h3>
                  <p className="text-xs text-[#ECE8DF]/60 font-sans mt-0.5 mb-4">
                    Changing a control reruns backend detrending calculation
                  </p>

                  <div className="space-y-2 mb-5">
                    <label className="text-[11px] font-sans font-bold tracking-widest text-[#ECE8DF]/70 block uppercase">
                      Detrending Algorithm
                    </label>
                    <div className="grid grid-cols-3 gap-1 bg-[#1B1A18] p-1 rounded-lg border border-[#ECE8DF]/15">
                      {['conservative', 'standard', 'aggressive'].map((mode) => (
                        <button
                          key={mode}
                          onClick={() => setDetrendMode(mode)}
                          className={`py-1.5 text-xs font-sans rounded capitalize transition-all ${
                            detrendMode === mode
                              ? 'bg-[#ECE8DF] text-[#141312] font-bold shadow-sm'
                              : 'text-[#ECE8DF]/60 hover:text-white'
                          }`}
                        >
                          {mode}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-2 mb-6 font-sans text-xs">
                    <div className="flex items-center justify-between p-2.5 rounded bg-[#1B1A18] border border-[#ECE8DF]/15">
                      <span className="text-[#ECE8DF]/80">Detected event markers</span>
                      <button
                        onClick={() => setShowEventMarkers(!showEventMarkers)}
                        className={`px-3 py-0.5 rounded text-[11px] font-bold ${
                          showEventMarkers ? 'bg-[#C5A059] text-[#141312]' : 'bg-[#141312] text-[#ECE8DF]/50'
                        }`}
                      >
                        {showEventMarkers ? 'ON' : 'OFF'}
                      </button>
                    </div>

                    <div className="flex items-center justify-between p-2.5 rounded bg-[#1B1A18] border border-[#ECE8DF]/15">
                      <span className="text-[#ECE8DF]/80">Quality-flagged points</span>
                      <button
                        onClick={() => setShowQualityFlags(!showQualityFlags)}
                        className={`px-3 py-0.5 rounded text-[11px] font-bold ${
                          !showQualityFlags ? 'bg-[#C5A059] text-[#141312]' : 'bg-[#141312] text-[#ECE8DF]/50'
                        }`}
                      >
                        {!showQualityFlags ? 'HIDE' : 'SHOW'}
                      </button>
                    </div>
                  </div>

                  {/* Measurements Box */}
                  <div className="bg-[#1B1A18] p-4 rounded-lg border border-[#ECE8DF]/15 space-y-2 font-mono text-xs">
                    <div className="text-[10px] text-[#C5A059] uppercase tracking-widest font-bold mb-2">
                      MEASUREMENTS
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-[#ECE8DF]/60">Period:</span>
                      <span className="text-white font-bold">~4.9 days</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-[#ECE8DF]/60">Depth:</span>
                      <span className="text-white font-bold">1.42% (from curve)</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-[#ECE8DF]/60">SNR:</span>
                      <span className="text-[#6EA893] font-bold">28.4 σ (backend)</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-[#ECE8DF]/60">Robustness:</span>
                      <span className="text-[#C5A059] font-bold">94.2% verified</span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => setActiveTab('gemma')}
                  className="chamfer-btn mt-6 w-full py-2.5 px-4 bg-[#ECE8DF] hover:bg-[#C5A059] text-[#141312] font-['Cinzel',serif] font-bold text-xs tracking-[0.16em] uppercase flex items-center justify-center gap-2"
                >
                  <span>Pass to AI Investigator</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: GEMMA 4 / EVIDENCE-BASED INVESTIGATOR (PDF Page 8) */}
        {activeTab === 'gemma' && (
          <div className="mt-6 space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Left Col: Candidate Evidence */}
              <div className="rounded-lg bg-[#141312] border border-[#ECE8DF]/15 p-5 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-xl font-['Playfair_Display',serif] font-normal text-white">
                      Candidate evidence
                    </h3>
                    <span className="text-[10px] font-sans font-bold tracking-wider text-[#C5A059] bg-[#1B1A18] px-2 py-0.5 rounded border border-[#C5A059]/40 uppercase">
                      Candidate != confirmed planet
                    </span>
                  </div>
                  <p className="text-xs text-[#ECE8DF]/60 font-sans mb-3">
                    Measured light curve and current human hypothesis
                  </p>

                  <LightCurveChart
                    data={activeCurveData}
                    height={180}
                    title="TIME (BTJD) // HOST STAR PHOTOMETRIC RECORD"
                  />

                  <div className="mt-4 space-y-2 bg-[#1B1A18] p-3 rounded-lg border border-[#ECE8DF]/15 font-mono text-xs">
                    <div className="flex items-center justify-between">
                      <span className="text-[#ECE8DF]/60">User guess:</span>
                      <span className="text-[#C5A059] font-bold capitalize">{hypothesis}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-[#ECE8DF]/60">BLS:</span>
                      <span className="text-white">repeating dip candidate</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-[#ECE8DF]/60">Quality:</span>
                      <span className="text-[#6EA893]">verified with 0 momentum dumps</span>
                    </div>
                  </div>
                </div>

                <div className="mt-6 pt-4 border-t border-[#ECE8DF]/15 text-[11px] font-sans text-[#ECE8DF]/60 flex items-center justify-between">
                  <span>Gemma 4 selects approved Python astrophysics tests</span>
                  <span className="text-[#C5A059]">3-call cap</span>
                </div>
              </div>

              {/* Right Col: Investigation Timeline */}
              <div className="rounded-lg bg-[#141312] border border-[#ECE8DF]/15 p-5 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-xl font-['Playfair_Display',serif] font-normal text-white">
                      Investigation timeline
                    </h3>
                    <span className="text-[10px] font-sans font-bold tracking-wider text-[#C5A059] bg-[#1B1A18] px-2.5 py-0.5 rounded border border-[#C5A059]/40 uppercase">
                      AI REASONING TRACE
                    </span>
                  </div>
                  <p className="text-xs text-[#ECE8DF]/60 font-sans mb-4">
                    DEMO MODE until a real Gemma backend is connected
                  </p>

                  <div className="space-y-3 font-sans">
                    <div className={`p-3 rounded-lg border transition-all ${aiStep >= 1 ? 'bg-[#1B1A18] border-[#C5A059]/50' : 'opacity-40 border-[#ECE8DF]/10'}`}>
                      <div className="text-[10px] font-bold tracking-wider text-[#C5A059] uppercase">
                        01 / Hypothesis
                      </div>
                      <div className="text-xs text-white mt-0.5 font-semibold">
                        Planet or eclipsing binary?
                      </div>
                    </div>

                    <div className={`p-3 rounded-lg border transition-all ${aiStep >= 2 ? 'bg-[#1B1A18] border-[#6B8EAE]/50' : 'opacity-40 border-[#ECE8DF]/10'}`}>
                      <div className="text-[10px] font-bold tracking-wider text-[#6B8EAE] uppercase">
                        02 / Tool selected
                      </div>
                      <div className="text-xs font-mono text-slate-200 mt-0.5">
                        check_odd_even_depth()
                      </div>
                    </div>

                    <div className={`p-3 rounded-lg border transition-all ${aiStep >= 3 ? 'bg-[#1B1A18] border-[#9D78A8]/50' : 'opacity-40 border-[#ECE8DF]/10'}`}>
                      <div className="text-[10px] font-bold tracking-wider text-[#9D78A8] uppercase">
                        03 / Tool result
                      </div>
                      <div className="text-xs font-mono text-slate-200 mt-0.5">
                        Depth comparison: measured output (Odd: 1.41% vs Even: 1.42%, delta &lt; 0.02%)
                      </div>
                    </div>

                    <div className={`p-3 rounded-lg border transition-all ${aiStep >= 4 ? 'bg-[#1B1A18] border-[#6EA893]/50' : 'opacity-40 border-[#ECE8DF]/10'}`}>
                      <div className="text-[10px] font-bold tracking-wider text-[#6EA893] uppercase">
                        04 / Evidence update
                      </div>
                      <div className="text-xs text-[#ECE8DF] mt-0.5 font-medium">
                        Binary hypothesis ruled out; exoplanet transit candidate confirmed plausible.
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-6 pt-4 border-t border-[#ECE8DF]/15 flex flex-wrap items-center gap-3">
                  <button
                    onClick={handleRunAiInvestigation}
                    disabled={isInvestigating}
                    className="chamfer-btn flex-1 py-2.5 px-4 bg-[#ECE8DF] hover:bg-[#C5A059] disabled:opacity-50 text-[#141312] font-['Cinzel',serif] font-bold text-xs tracking-[0.16em] uppercase flex items-center justify-center gap-2"
                  >
                    {isInvestigating ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        <span>Running Tests...</span>
                      </>
                    ) : (
                      <>
                        <Play className="w-3.5 h-3.5" />
                        <span>Start investigation</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={() => setActiveTab('casefile')}
                    className="chamfer-btn py-2.5 px-4 bg-[#1B1A18] hover:bg-[#23211E] border border-[#ECE8DF]/25 text-[#ECE8DF] font-['Cinzel',serif] font-bold text-xs tracking-[0.16em] uppercase"
                  >
                    View case file
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: SCIENTIFIC CASE FILE / EXPORT (PDF Page 9) */}
        {activeTab === 'casefile' && (
          <div className="mt-6 space-y-6">
            <div className="rounded-lg bg-[#141312] border border-[#ECE8DF]/15 p-6 space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-[#ECE8DF]/15 gap-2">
                <div>
                  <h3 className="text-2xl font-['Playfair_Display',serif] font-normal text-white">
                    CASE FILE / {currentMission.ticId} / {currentMission.sector}
                  </h3>
                  <div className="text-xs font-mono text-[#C5A059] mt-0.5">
                    STATUS: candidate, not confirmed discovery
                  </div>
                </div>
                <span className="text-[10px] font-sans font-bold tracking-widest text-[#ECE8DF]/70 bg-[#1B1A18] px-3 py-1.5 rounded border border-[#ECE8DF]/15 uppercase">
                  REPRODUCIBLE RESEARCH MANIFEST
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-[#1B1A18] p-4 rounded-lg border border-[#ECE8DF]/15">
                  <div className="text-xs font-sans font-bold tracking-wider text-[#C5A059] uppercase mb-2">
                    OBSERVATION
                  </div>
                  <div className="space-y-1.5 text-xs font-mono text-[#ECE8DF]/80">
                    <div>NASA TESS / MAST Science Archive</div>
                    <div>{currentMission.ticId}, {currentMission.sector}, 27.4 days baseline</div>
                    <div className="text-[#ECE8DF]/50 text-[11px]">SAP + PDCSAP calibration provenance verified</div>
                  </div>
                </div>

                <div className="bg-[#1B1A18] p-4 rounded-lg border border-[#ECE8DF]/15">
                  <div className="text-xs font-sans font-bold tracking-wider text-[#6B8EAE] uppercase mb-2">
                    MEASUREMENTS
                  </div>
                  <div className="space-y-1.5 text-xs font-mono text-[#ECE8DF]/80">
                    <div>Event type: periodic dip</div>
                    <div>Period: 4.887 ± 0.002 days / depth: 1.42%</div>
                    <div className="text-[#ECE8DF]/50 text-[11px]">Detrending: standard spline + quality flag mask</div>
                  </div>
                </div>

                <div className="bg-[#1B1A18] p-4 rounded-lg border border-[#ECE8DF]/15">
                  <div className="text-xs font-sans font-bold tracking-wider text-[#6EA893] uppercase mb-2">
                    EVIDENCE
                  </div>
                  <div className="space-y-1.5 text-xs font-mono text-[#ECE8DF]/80">
                    <div>For: repeated dimming, symmetrical ingress/egress</div>
                    <div>Against: binary not fully ruled out until radial velocity</div>
                    <div className="text-[#ECE8DF]/50 text-[11px]">Tests: check_odd_even_depth, centroid_motion_test</div>
                  </div>
                </div>

                <div className="bg-[#1B1A18] p-4 rounded-lg border border-[#ECE8DF]/15">
                  <div className="text-xs font-sans font-bold tracking-wider text-[#9D78A8] uppercase mb-2">
                    NEXT STEPS
                  </div>
                  <div className="space-y-1.5 text-xs font-mono text-[#ECE8DF]/80">
                    <div>Check other available TESS sectors</div>
                    <div>Review secondary eclipse depths</div>
                    <div className="text-[#ECE8DF]/50 text-[11px]">Gaia DR3 proper motion catalog crossmatch</div>
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-[#ECE8DF]/15 flex flex-wrap items-center gap-3">
                <button
                  onClick={handleExportJSON}
                  className="chamfer-btn py-2.5 px-4 bg-[#ECE8DF] hover:bg-[#C5A059] text-[#141312] font-['Cinzel',serif] font-bold text-xs tracking-[0.16em] uppercase flex items-center gap-2"
                >
                  <Download className="w-4 h-4" />
                  <span>Export JSON</span>
                </button>

                <button
                  onClick={handlePrint}
                  className="chamfer-btn py-2.5 px-4 bg-[#1B1A18] hover:bg-[#23211E] border border-[#ECE8DF]/25 text-[#ECE8DF] font-['Cinzel',serif] font-bold text-xs tracking-[0.16em] uppercase flex items-center gap-2"
                >
                  <Printer className="w-4 h-4 text-[#C5A059]" />
                  <span>Print / Save PDF</span>
                </button>

                <button
                  onClick={handleCopySummary}
                  className="chamfer-btn py-2.5 px-4 bg-[#1B1A18] hover:bg-[#23211E] border border-[#ECE8DF]/25 text-[#ECE8DF] font-['Cinzel',serif] font-bold text-xs tracking-[0.16em] uppercase flex items-center gap-2"
                >
                  {copiedSummary ? (
                    <>
                      <Check className="w-4 h-4 text-[#6EA893]" />
                      <span className="text-[#6EA893]">Summary Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4 text-[#C5A059]" />
                      <span>Copy summary</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
